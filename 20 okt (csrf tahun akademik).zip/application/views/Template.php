<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-name"   content="<?= $this->security->get_csrf_token_name(); ?>">
    <meta name="csrf-hash"   content="<?= $this->security->get_csrf_hash(); ?>">
    <meta name="csrf-cookie" content="<?= $this->config->item('csrf_cookie_name'); ?>">

    <!--favicon-->
    <link rel="icon" href="<?php echo base_url() ?>assets/images/logo.jpg" type="image/png" />
    <?php $this->load->view($css) ?>
    <title>SIAKAD | Ma'had Aly</title>
  </head>

  <body>
    <!--wrapper-->
    <div class="wrapper">
      <!--sidebar wrapper -->
      <div class="sidebar-wrapper" data-simplebar="true">
        <div class="sidebar-header">
          <div>
            <img src="<?php echo base_url() ?>assets/images/logo.jpg" class="logo-icon" alt="logo icon" />
          </div>
          <div>
            <h4 class="logo-text">SIAKAD</h4>
          </div>
          <div class="toggle-icon ms-auto"><i class="bx bx-arrow-to-left"></i></div>
        </div>
        <!--navigation-->
        <!--sidebar wrapper -->
        <div class="sidebar-wrapper" data-simplebar="true">
          <div class="sidebar-header">
            <div>
              <img src="<?php echo base_url() ?>assets/images/logo.jpg" class="logo-icon" alt="logo icon" />
            </div>
            <div>
              <h4 class="logo-text">SIAKAD</h4>
            </div>
            <div class="toggle-icon ms-auto"><i class="bx bx-arrow-to-left"></i></div>
          </div>
          <!--navigation-->

          <!-- **** admin *** -->
          <?php if ($this->session->userdata('role') == 'petugas'): ?>
          <ul class="metismenu" id="menu">
            <li>
              <a href="<?php echo base_url() ?>" class="">
                <div class="parent-icon"><i class="bx bx-home-circle"></i></div>
                <div class="menu-title">Dashboard</div>
              </a>
            </li>
            <li class="menu-label">Manajemen Data</li>
            <li></li>
            <li>
              <a href="<?php echo base_url() ?>Tahun_akademik">
                <div class="parent-icon"><i class="bx bx-calendar-star"></i></div>
                <div class="menu-title">Tahun Akademik</div>
              </a>
            </li>
            <li>
              <a href="<?php echo base_url() ?>Mahasiswa">
                <div class="parent-icon"><i class="bx bx-user"></i></div>
                <div class="menu-title">Mahasiswa</div>
              </a>
            </li>
            <li>
              <a href="<?php echo base_url() ?>Dosen">
                <div class="parent-icon"><i class="bx bx-chalkboard"></i></div>
                <div class="menu-title">Dosen</div>
              </a>
            </li>
            <li>
              <a href="<?php echo base_url() ?>Matakuliah">
                <div class="parent-icon"><i class="bx bx-book"></i></div>
                <div class="menu-title">Matakuliah</div>
              </a>
            </li>
            <li>
              <a class="has-arrow" href="javascript:;">
                <div class="parent-icon"><i class="bx bx-buildings"></i></div>
                <div class="menu-title">Kelas</div>
              </a>
              <ul>
                <li>
                  <a href="<?php echo base_url() ?>Kelas"><i class="bx bx-right-arrow-alt"></i> Kelas</a>
                </li>
                <li>
                  <a href="<?php echo base_url() ?>distribusi_kelas"><i class="bx bx-right-arrow-alt"></i>Distribusi Kelas</a>
                </li>
              </ul>
            </li>
            <li>
              <a class="has-arrow" href="javascript:;">
                <div class="parent-icon"><i class="bx bx-calendar"></i></div>
                <div class="menu-title">Awal Semester</div>
              </a>
              <ul>
                <li>
                  <a href="<?php echo base_url() ?>Distribusi_matkul"><i class="bx bx-share-alt"></i> Distribusi Matakuliah</a>
                </li> 
                <li>
                  <a href="<?php echo base_url() ?>Generate_krs"><i class="bx bx-cog"></i> Generate KRS</a>
                </li>
                <li>
                  <a href="<?php echo base_url() ?>Detail_krs"><i class="bx bx-detail"></i> Detail KRS</a>
                </li>
              </ul>
            </li>
            <li>
              <a class="has-arrow" href="javascript:;">
                <div class="parent-icon"><i class="bx bx-calendar"></i></div>
                <div class="menu-title">Penilaian</div>
              </a>
              <ul>
                <li>
                  <a href="<?php echo base_url() ?>Penilaian"><i class="bx bx-user-check"></i>Penilaian</a>
                </li> 
                <li>
                  <a href="<?php echo base_url() ?>Rekap_nilai"><i class="bx bx-file"></i> Rekap Nilai</a>
                </li>
              </ul>
            </li>

            <li>
              <a class="has-arrow" href="javascript:;">
                <div class="parent-icon"><i class="bx bx-calendar"></i></div>
                <div class="menu-title">Presensi Perkuliahan</div>
              </a>
              <ul>
                <li>
                  <a href="<?php echo base_url() ?>Presensi"><i class="bx bx-user-check"></i>Presensi Perkuliahan</a>
                </li> 
                <li>
                  <a href="<?php echo base_url() ?>Rekap_presensi"><i class="bx bx-file"></i> Rekap Presensi</a>
                </li>
              </ul>
            </li>
            <li>
              <a class="has-arrow" href="javascript:;">
                <div class="parent-icon"><i class="bx bx-calendar"></i></div>
                <div class="menu-title">Cetak Jadwal</div>
              </a>
              <ul>
                <li>
                  <a href="<?php echo base_url() ?>Cetak_perdosen"><i class="bx bx-user-check"></i>Per Dosen</a>
                </li> 
                <li>
                  <a href="<?php echo base_url() ?>Cetak_perkelas"><i class="bx bx-file"></i> Per Kelas</a>
                </li>
              </ul>
            </li>
            <li>
              <a href="<?php echo base_url() ?>Pelanggaran">
                <div class="parent-icon"><i class="bx bx-user"></i></div>
                <div class="menu-title">Pelanggaran</div>
              </a>
            </li>
            <li class="menu-label">
              <hr>
            </li>
            <li>
              <a class="has-arrow" href="javascript:;">
                <div class="parent-icon"><i class="bx bx-detail"></i></div>
                <div class="menu-title">Surat Keterangan</div>
              </a>
              <ul>
                <li>
                  <a href="<?php echo base_url() ?>Surataktif"><i class="bx bx-right-arrow-alt"></i> Aktif Kuliah</a>
                </li>
                <li>
                  <a href="surat_cuti.html"><i class="bx bx-right-arrow-alt"></i>Pengajuan Cuti</a>
                </li>
              </ul>
            </li>
            
          </ul>

          <?php endif; ?>
          <?php if ($this->session->userdata('role') == 'mahasiswa'): ?>
          <!-- *** Mahasiswa *** -->

          <ul class="metismenu" id="menu">
            <li>
              <a href="<?php echo base_url() ?>Dashboard_mahasiswa" class="">
                <div class="parent-icon"><i class="bx bx-home-circle"></i></div>
                <div class="menu-title">Dashboard</div>
              </a>
            </li>
            <!-- <li class="menu-label">Manajemen Data</li> -->
            <li>
              <a href="<?php echo base_url() ?>Mahasiswa/detail/<?php echo $this->session->userdata('id')?>">
                <div class="parent-icon"><i class="bx bx-user"></i></div>
                <div class="menu-title">Data Diri</div>
              </a>
            </li>
            <li>
              <a href="<?php echo base_url() ?>Khs_mahasiswa">
                <div class="parent-icon"><i class="bx bx-grid-alt"></i></div>
                <div class="menu-title">KHS</div>
              </a>
            </li>
          </ul>
          <?php endif; ?>
          <?php if ($this->session->userdata('role') == 'dosen'): ?>
          <!-- *** Dosen *** -->
          <ul class="metismenu" id="menu">
            <li>
              <a href="<?php echo base_url() ?>Dashboard_dosen" class="">
                <div class="parent-icon"><i class="bx bx-home-circle"></i></div>
                <div class="menu-title">Dashboard</div>
              </a>
            </li>
            <li>
            <a href="Profil.html">
              <div class="parent-icon"><i class="bx bx-user"></i></div>
              <div class="menu-title">Data Diri Dosen</div>
            </a>
          </li>
          <li>
            <a href="<?php echo base_url() ?>Cetak_perdosen">
              <div class="parent-icon"><i class="bx bx-grid-alt"></i></div>
              <div class="menu-title">Jadwal Perkuliahan</div>
            </a>
          </li>
          <li>
            <a href="<?php echo base_url() ?>Penilaian">
              <div class="parent-icon"><i class="bx bx-message-square-edit"></i></div>
              <div class="menu-title">Penilaian</div>
            </a>
          </li>
          </ul>
          <?php endif; ?>
          <!--end navigation-->
        </div>
        <!--end sidebar wrapper -->
        <!--start header -->
        <header>
          <div class="topbar d-flex align-items-center">
            <nav class="navbar navbar-expand">
              <div class="mobile-toggle-menu"><i class="bx bx-menu"></i></div>
              <div class="search-bar flex-grow-1">
                <div class="position-relative search-bar-box">
                  <span class="position-absolute top-50 search-close translate-middle-y"></span>
                </div>
              </div>
              <div class="top-menu ms-auto">
                <ul class="navbar-nav align-items-center">
                  <li class="nav-item mobile-search-icon">
                    <a class="nav-link" href="#"> <i class="bx bx-search"></i> </a>
                  </li>
                  <li class="nav-item dropdown dropdown-large">
                    <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"> </a>
                    <div class="dropdown-menu dropdown-menu-end">
                      <div class="row row-cols-3 g-3 p-3"></div>
                    </div>
                  </li>
                  <?php
                  // Jalankan query untuk mendapatkan tahun aktif
                  $query = $this->db->get_where('tahun_akademik', array('status' => 'aktif'));
                  $tahun_aktif = $query->row();

                  if ($tahun_aktif) {
                      echo "<span>Tahun Aktif : " . $tahun_aktif->tahun_akademik . "</span>";
                  } else {
                      echo "<span>Tahun Akademik : Tidak ada tahun aktif</span>";
                  }
                  ?>

                  <li class="nav-item dropdown dropdown-large">
                    <a class="nav-link dropdown-toggle dropdown-toggle-nocaret position-relative" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"> </a>
                    <div class="dropdown-menu dropdown-menu-end">
                      <a href="javascript:;">
                        <div class="msg-header">
                          <p class="msg-header-title">Notifications</p>
                          <p class="msg-header-clear ms-auto">Marks all as read</p>
                        </div>
                      </a>
                      <div class="header-notifications-list"></div>
                      <a href="javascript:;">
                        <div class="text-center msg-footer">View All Notifications</div>
                      </a>
                    </div>
                  </li>
                  <li class="nav-item dropdown dropdown-large">
                    <a class="nav-link dropdown-toggle dropdown-toggle-nocaret position-relative" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"> </a>
                    <div class="dropdown-menu dropdown-menu-end">
                      <a href="javascript:;">
                        <div class="msg-header">
                          <p class="msg-header-title">Messages</p>
                          <p class="msg-header-clear ms-auto">Marks all as read</p>
                        </div>
                      </a>
                      <div class="header-message-list"></div>
                      <a href="javascript:;">
                        <div class="text-center msg-footer">View All Messages</div>
                      </a>
                    </div>
                  </li>
                </ul>
              </div>
              <div class="user-box dropdown">
                <a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <img src="<?php echo base_url() ?>assets/images/avatars/a.png" class="user-img" alt="user avatar" />
                  <div class="user-info ps-3">
                    <p class="user-name mb-0"><?php echo $this->session->userdata('username')?></p>
                    <p class="designattion mb-0"><?php echo $this->session->userdata('role')?></p>
                  </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                  
                  <li>
                    <a class="dropdown-item" href="<?php echo base_url() ?>Login/logout"><i class="bx bx-log-out-circle"></i><span>Logout</span></a>
                  </li>
                </ul>
              </div>
            </nav>
          </div>
        </header>
        <!--end navigation-->
      </div>
      <!--end sidebar wrapper -->
      <!--start header -->
      <header>
        <div class="topbar d-flex align-items-center">
          <nav class="navbar navbar-expand">
            <div class="mobile-toggle-menu"><i class="bx bx-menu"></i></div>
            <div class="search-bar flex-grow-1">
              <div class="position-relative search-bar-box">
                <span class="position-absolute top-50 search-close translate-middle-y"><i class="bx bx-x"></i></span>
              </div>
            </div>
            <div class="top-menu ms-auto">
              <ul class="navbar-nav align-items-center">
                <li class="nav-item mobile-search-icon">
                  <a class="nav-link" href="#"> <i class="bx bx-search"></i> </a>
                </li>
                <li class="nav-item dropdown dropdown-large">
                  <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"> <i class="bx bx-category"></i> </a>
                  <div class="dropdown-menu dropdown-menu-end">
                    <div class="row row-cols-3 g-3 p-3">
                      <div class="col text-center">
                        <div class="app-box mx-auto bg-gradient-cosmic text-white"><i class="bx bx-group"></i></div>
                        <div class="app-title">Teams</div>
                      </div>
                      <div class="col text-center">
                        <div class="app-box mx-auto bg-gradient-burning text-white"><i class="bx bx-atom"></i></div>
                        <div class="app-title">Projects</div>
                      </div>
                      <div class="col text-center">
                        <div class="app-box mx-auto bg-gradient-lush text-white"><i class="bx bx-shield"></i></div>
                        <div class="app-title">Tasks</div>
                      </div>
                      <div class="col text-center">
                        <div class="app-box mx-auto bg-gradient-kyoto text-dark"><i class="bx bx-notification"></i></div>
                        <div class="app-title">Feeds</div>
                      </div>
                      <div class="col text-center">
                        <div class="app-box mx-auto bg-gradient-blues text-dark"><i class="bx bx-file"></i></div>
                        <div class="app-title">Files</div>
                      </div>
                      <div class="col text-center">
                        <div class="app-box mx-auto bg-gradient-moonlit text-white"><i class="bx bx-filter-alt"></i></div>
                        <div class="app-title">Alerts</div>
                      </div>
                    </div>
                  </div>
                </li>
                <li class="nav-item dropdown dropdown-large">
                  <a class="nav-link dropdown-toggle dropdown-toggle-nocaret position-relative" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <span class="alert-count">7</span>
                    <i class="bx bx-bell"></i>
                  </a>
                  <div class="dropdown-menu dropdown-menu-end">
                    <a href="javascript:;">
                      <div class="msg-header">
                        <p class="msg-header-title">Notifications</p>
                        <p class="msg-header-clear ms-auto">Marks all as read</p>
                      </div>
                    </a>
                    <div class="header-notifications-list">
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="notify bg-light-primary text-primary"><i class="bx bx-group"></i></div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">New Customers<span class="msg-time float-end">14 Sec ago</span></h6>
                            <p class="msg-info">5 new user registered</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="notify bg-light-danger text-danger"><i class="bx bx-cart-alt"></i></div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">New Orders <span class="msg-time float-end">2 min ago</span></h6>
                            <p class="msg-info">You have recived new orders</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="notify bg-light-success text-success"><i class="bx bx-file"></i></div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">24 PDF File<span class="msg-time float-end">19 min ago</span></h6>
                            <p class="msg-info">The pdf files generated</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="notify bg-light-warning text-warning"><i class="bx bx-send"></i></div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">Time Response <span class="msg-time float-end">28 min ago</span></h6>
                            <p class="msg-info">5.1 min avarage time response</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="notify bg-light-info text-info"><i class="bx bx-home-circle"></i></div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">New Product Approved <span class="msg-time float-end">2 hrs ago</span></h6>
                            <p class="msg-info">Your new product has approved</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="notify bg-light-danger text-danger"><i class="bx bx-message-detail"></i></div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">New Comments <span class="msg-time float-end">4 hrs ago</span></h6>
                            <p class="msg-info">New customer comments recived</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="notify bg-light-success text-success"><i class="bx bx-check-square"></i></div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">Your item is shipped <span class="msg-time float-end">5 hrs ago</span></h6>
                            <p class="msg-info">Successfully shipped your item</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="notify bg-light-primary text-primary"><i class="bx bx-user-pin"></i></div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">New 24 authors<span class="msg-time float-end">1 day ago</span></h6>
                            <p class="msg-info">24 new authors joined last week</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="notify bg-light-warning text-warning"><i class="bx bx-door-open"></i></div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">Defense Alerts <span class="msg-time float-end">2 weeks ago</span></h6>
                            <p class="msg-info">45% less alerts last 4 weeks</p>
                          </div>
                        </div>
                      </a>
                    </div>
                    <a href="javascript:;">
                      <div class="text-center msg-footer">View All Notifications</div>
                    </a>
                  </div>
                </li>
                <li class="nav-item dropdown dropdown-large">
                  <a class="nav-link dropdown-toggle dropdown-toggle-nocaret position-relative" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <span class="alert-count">8</span>
                    <i class="bx bx-comment"></i>
                  </a>
                  <div class="dropdown-menu dropdown-menu-end">
                    <a href="javascript:;">
                      <div class="msg-header">
                        <p class="msg-header-title">Messages</p>
                        <p class="msg-header-clear ms-auto">Marks all as read</p>
                      </div>
                    </a>
                    <div class="header-message-list">
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="user-online">
                            <img src="<?php echo base_url() ?>assets/images/avatars/avatar-1.png" class="msg-avatar" alt="user avatar" />
                          </div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">Daisy Anderson <span class="msg-time float-end">5 sec ago</span></h6>
                            <p class="msg-info">The standard chunk of lorem</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="user-online">
                            <img src="<?php echo base_url() ?>assets/images/avatars/avatar-1.png" class="msg-avatar" alt="user avatar" />
                          </div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">Althea Cabardo <span class="msg-time float-end">14 sec ago</span></h6>
                            <p class="msg-info">Many desktop publishing packages</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="user-online">
                            <img src="<?php echo base_url() ?>assets/images/avatars/avatar-1.png" class="msg-avatar" alt="user avatar" />
                          </div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">Oscar Garner <span class="msg-time float-end">8 min ago</span></h6>
                            <p class="msg-info">Various versions have evolved over</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="user-online">
                            <img src="<?php echo base_url() ?>assets/images/avatars/avatar-1.png" class="msg-avatar" alt="user avatar" />
                          </div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">Katherine Pechon <span class="msg-time float-end">15 min ago</span></h6>
                            <p class="msg-info">Making this the first true generator</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="user-online">
                            <img src="<?php echo base_url() ?>assets/images/avatars/avatar-1.png" class="msg-avatar" alt="user avatar" />
                          </div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">Amelia Doe <span class="msg-time float-end">22 min ago</span></h6>
                            <p class="msg-info">Duis aute irure dolor in reprehenderit</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="user-online">
                            <img src="<?php echo base_url() ?>assets/images/avatars/avatar-1.png" class="msg-avatar" alt="user avatar" />
                          </div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">Cristina Jhons <span class="msg-time float-end">2 hrs ago</span></h6>
                            <p class="msg-info">The passage is attributed to an unknown</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="user-online">
                            <img src="<?php echo base_url() ?>assets/images/avatars/avatar-1.png" class="msg-avatar" alt="user avatar" />
                          </div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">James Caviness <span class="msg-time float-end">4 hrs ago</span></h6>
                            <p class="msg-info">The point of using Lorem</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="user-online">
                            <img src="<?php echo base_url() ?>assets/images/avatars/avatar-1.png" class="msg-avatar" alt="user avatar" />
                          </div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">Peter Costanzo <span class="msg-time float-end">6 hrs ago</span></h6>
                            <p class="msg-info">It was popularised in the 1960s</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="user-online">
                            <img src="<?php echo base_url() ?>assets/images/avatars/avatar-1.png" class="msg-avatar" alt="user avatar" />
                          </div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">David Buckley <span class="msg-time float-end">2 hrs ago</span></h6>
                            <p class="msg-info">Various versions have evolved over</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="user-online">
                            <img src="<?php echo base_url() ?>assets/images/avatars/avatar-1.png" class="msg-avatar" alt="user avatar" />
                          </div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">Thomas Wheeler <span class="msg-time float-end">2 days ago</span></h6>
                            <p class="msg-info">If you are going to use a passage</p>
                          </div>
                        </div>
                      </a>
                      <a class="dropdown-item" href="javascript:;">
                        <div class="d-flex align-items-center">
                          <div class="user-online">
                            <img src="<?php echo base_url() ?>assets/images/avatars/avatar-1.png" class="msg-avatar" alt="user avatar" />
                          </div>
                          <div class="flex-grow-1">
                            <h6 class="msg-name">Johnny Seitz <span class="msg-time float-end">5 days ago</span></h6>
                            <p class="msg-info">All the Lorem Ipsum generators</p>
                          </div>
                        </div>
                      </a>
                    </div>
                    <a href="javascript:;">
                      <div class="text-center msg-footer">View All Messages</div>
                    </a>
                  </div>
                </li>
              </ul>
            </div>
            <div class="user-box dropdown">
              <a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <img src="<?php echo base_url() ?>assets/images/avatars/avatar-1.png" class="user-img" alt="user avatar" />
                <div class="user-info ps-3">
                  <p class="user-name mb-0">Pauline Seitz</p>
                  <p class="designattion mb-0">Web Designer</p>
                </div>
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li>
                  <a class="dropdown-item" href="<?php echo base_url() ?>Login/logout"><i class="bx bx-log-out-circle"></i><span>Logout</span></a>
                </li>
              </ul>
            </div>
          </nav>
        </div>
      </header>
      <!--end header -->
      <!--start page wrapper -->
      <!--start page wrapper -->
      
        <?php $this->load->view($content) ?>

      <!--end page wrapper -->
      <!--start overlay-->
      <div class="overlay toggle-icon"></div>
      <!--end overlay-->
      <!--Start Back To Top Button-->
      <a href="javaScript:;" class="back-to-top"><i class="bx bxs-up-arrow-alt"></i></a>
      <!--End Back To Top Button-->
      <footer class="page-footer">
        <p class="mb-0">Copyright © 2025. Ma'had Aly Sukorejo.</p>
      </footer>
    </div>
    <!--end wrapper-->
    <!--start switcher-->
    <div class="switcher-wrapper">
      <div class="switcher-btn"><i class="bx bx-cog bx-spin"></i></div>
      <div class="switcher-body">
        <div class="d-flex align-items-center">
          <h5 class="mb-0 text-uppercase">Theme Customizer</h5>
          <button type="button" class="btn-close ms-auto close-switcher" aria-label="Close"></button>
        </div>
        <hr />
        <h6 class="mb-0">Theme Styles</h6>
        <hr />
        <div class="d-flex align-items-center justify-content-between">
          <div class="form-check">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="lightmode" checked />
            <label class="form-check-label" for="lightmode">Light</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="darkmode" />
            <label class="form-check-label" for="darkmode">Dark</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="semidark" />
            <label class="form-check-label" for="semidark">Semi Dark</label>
          </div>
        </div>
        <hr />
        <div class="form-check">
          <input class="form-check-input" type="radio" id="minimaltheme" name="flexRadioDefault" />
          <label class="form-check-label" for="minimaltheme">Minimal Theme</label>
        </div>
        <hr />
        <h6 class="mb-0">Header Colors</h6>
        <hr />
        <div class="header-colors-indigators">
          <div class="row row-cols-auto g-3">
            <div class="col">
              <div class="indigator headercolor1" id="headercolor1"></div>
            </div>
            <div class="col">
              <div class="indigator headercolor2" id="headercolor2"></div>
            </div>
            <div class="col">
              <div class="indigator headercolor3" id="headercolor3"></div>
            </div>
            <div class="col">
              <div class="indigator headercolor4" id="headercolor4"></div>
            </div>
            <div class="col">
              <div class="indigator headercolor5" id="headercolor5"></div>
            </div>
            <div class="col">
              <div class="indigator headercolor6" id="headercolor6"></div>
            </div>
            <div class="col">
              <div class="indigator headercolor7" id="headercolor7"></div>
            </div>
            <div class="col">
              <div class="indigator headercolor8" id="headercolor8"></div>
            </div>
          </div>
        </div>
        <hr />
        <h6 class="mb-0">Sidebar Backgrounds</h6>
        <hr />
        <div class="header-colors-indigators">
          <div class="row row-cols-auto g-3">
            <div class="col">
              <div class="indigator sidebarcolor1" id="sidebarcolor1"></div>
            </div>
            <div class="col">
              <div class="indigator sidebarcolor2" id="sidebarcolor2"></div>
            </div>
            <div class="col">
              <div class="indigator sidebarcolor3" id="sidebarcolor3"></div>
            </div>
            <div class="col">
              <div class="indigator sidebarcolor4" id="sidebarcolor4"></div>
            </div>
            <div class="col">
              <div class="indigator sidebarcolor5" id="sidebarcolor5"></div>
            </div>
            <div class="col">
              <div class="indigator sidebarcolor6" id="sidebarcolor6"></div>
            </div>
            <div class="col">
              <div class="indigator sidebarcolor7" id="sidebarcolor7"></div>
            </div>
            <div class="col">
              <div class="indigator sidebarcolor8" id="sidebarcolor8"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end switcher-->
    <!-- Bootstrap JS -->
    
    <?php $this->load->view($ajax) ?>
  </body>
</html>
