<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller
{
    /**
     * Apakah halaman ini butuh login?
     * Set ke FALSE jika controller publik (mis. halaman landing).
     */
    protected $auth_required = TRUE;

    /**
     * Daftar role yang diizinkan untuk seluruh controller ini.
     * Kosong = tidak dibatasi (selama logged in).
     * Contoh: ['petugas','dosen']
     */
    protected $allowed_roles = [];

    /**
     * Aturan role per-method (override allowed_roles).
     * Key = nama method; Value = array role yg boleh.
     * Contoh:
     * protected $role_map = [
     *   'index'  => ['petugas','dosen','mahasiswa'],
     *   'create' => ['petugas'],
     * ];
     */
    protected $role_map = [];

    public function __construct()
    {
        parent::__construct();

        // Header keamanan dasar (opsional tapi bagus)
        // application/core/MY_Controller.php
        $this->output
            ->set_header('X-Frame-Options: DENY')
            ->set_header('X-Content-Type-Options: nosniff')
            ->set_header('Referrer-Policy: strict-origin-when-cross-origin')
            ->set_header(
            "Content-Security-Policy: ".
            "default-src 'self'; ".
            "img-src 'self' data:; ".
            "script-src 'self' https://cdn.jsdelivr.net 'unsafe-eval'; ".
            "style-src 'self' 'unsafe-inline'; ".
            "font-src 'self' data:; ".
            "connect-src 'self'; ".
            "frame-ancestors 'none';"
        );

          


        if (!$this->auth_required) {
            return; // controller publik
        }

        // 1) Wajib login
        if (!$this->session->userdata('logged_in')) {
            $this->deny_and_redirect('Silakan login terlebih dahulu.');
            return;
        }

        // 2) Ambil role user (lowercase sesuai controller login kita)
        $user_role = strtolower((string)$this->session->userdata('role'));

        // 3) Cek pembatasan level controller (jika ada)
        if (!empty($this->allowed_roles) && !$this->role_in($user_role, $this->allowed_roles)) {
            $this->deny_and_redirect('Akses tidak diizinkan.');
            return;
        }

        // 4) Cek pembatasan level method (override)
        $method = $this->router->fetch_method();
        if (!empty($this->role_map) && isset($this->role_map[$method])) {
            $allowed = array_map('strtolower', (array)$this->role_map[$method]);
            if (!$this->role_in($user_role, $allowed)) {
                $this->deny_and_redirect('Akses tidak diizinkan.');
                return;
            }
        }
    }

    /** Helper: cek role user ada di daftar yang diizinkan */
    protected function role_in($user_role, array $allowed): bool
    {
        return in_array(strtolower($user_role), array_map('strtolower', $allowed), true);
    }

    /** Helper: tolak & redirect */
    protected function deny_and_redirect($message = 'Akses tidak diizinkan.')
    {
        $this->session->set_flashdata('error', $message);
        redirect('login');
        exit;
    }

    /**
     * Helper opsional: panggil di dalam method ketika butuh aturan khusus dinamis
     * Contoh pemakaian di method:
     *   $this->require_roles(['petugas','dosen']);
     */
    protected function require_roles(array $roles)
    {
        $user_role = strtolower((string)$this->session->userdata('role'));
        if (!$this->role_in($user_role, $roles)) {
            $this->deny_and_redirect('Akses tidak diizinkan.');
        }
    }
}

//CARA PAKAI DI CONTROLLER

//Controller dengan multi-role untuk semua method
// Semua method di controller ini boleh diakses petugas & dosen
//  protected $allowed_roles = ['petugas', 'dosen'];


//Controller dengan aturan berbeda per-method
// Default: semua role login boleh (allowed_roles kosong)
// Override per-method:
// protected $role_map = [
//     'index'  => ['petugas','dosen','mahasiswa'], // lihat jadwal
//     'create' => ['petugas'],                     // hanya petugas boleh buat
//     'edit'   => ['petugas','dosen'],             // petugas & dosen boleh edit
//     'hapus'  => ['petugas'],                     // hanya petugas
// ];

// public function index()  { $this->load->view('jadwal/index'); }
// public function create() { $this->load->view('jadwal/create'); }

// Controller publik (tanpa login)
// protected $auth_required = FALSE; // halaman publik